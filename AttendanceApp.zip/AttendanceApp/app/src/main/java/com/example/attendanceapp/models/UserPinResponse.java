package com.example.attendanceapp.models;

import com.squareup.moshi.Json;

public class UserPinResponse {

    @Json(name = "id")
    private int id;

    @Json(name = "message")
    private String message;

    @Json(name = "status")
    private boolean status;

    public int getID() {
        return id;
    }

    public void setID(int id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String name) {
        this.message = name;
    }

    public boolean getStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}

//transform to kotlin