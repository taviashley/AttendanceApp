package com.example.attendanceapp.configs;

import com.example.attendanceapp.Definitions;
import com.squareup.moshi.Moshi;

import okhttp3.OkHttpClient;

import retrofit2.Retrofit;
import retrofit2.converter.moshi.MoshiConverterFactory;

public class GetRequest extends AbstractRequest {

    public GetRequest() {
        super();
    }

    @Override
    protected boolean getRetryOnConnectionFailure() {
        return false;
    }

    public static class Builder {
        private GetRequest request;
        private Retrofit.Builder retrofit;

        public Builder() {
            request = new GetRequest();

            Moshi moshi = new Moshi.Builder()
                    .add(new DateAdapter())
                    .add(new LinkedHashSetOfStringAdapter())
                    .build();

                retrofit = new Retrofit.Builder()
                        .baseUrl(Definitions.USER_PIN_WEBSERVICE)
                        .addConverterFactory(new NullOnEmptyConverterFactory())
                        .addConverterFactory(MoshiConverterFactory.create(moshi).asLenient());

        }

        public Builder setBaseUrl(String url) {
            retrofit.baseUrl(url);
            return this;
        }

        public Builder setTimeout(OkHttpClient.Builder builder) {

            retrofit.client(builder.build());
            return this;
        }

        public Retrofit build() {
            return retrofit.build();
        }
    }
}