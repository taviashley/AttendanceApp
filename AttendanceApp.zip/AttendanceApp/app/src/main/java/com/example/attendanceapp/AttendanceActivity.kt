package com.example.attendanceapp

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.NavController
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import com.example.attendanceapp.service.RunServiceOnBoot

class AttendanceActivity : AppCompatActivity() {

    private lateinit var navigationController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        //Defines CourseActivity as the navHost
        navigationController = findNavController(R.id.main_activity)
        NavigationUI.setupActionBarWithNavController(this, navigationController)

        val intent1 = Intent(this, RunServiceOnBoot::class.java)
        startService(intent1)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

        supportActionBar?.hide()

        //Set the app to take the entire screen
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
    }

    override fun onPause() {
        super.onPause()
        val activityManager = applicationContext
            .getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        activityManager.moveTaskToFront(taskId, 0)
    }

    fun showProgressDialog() {
        spin_kit.visibility = View.VISIBLE
    }

    fun hideProgressDialog() {
        spin_kit.visibility = View.GONE
    }
}