package com.example.attendanceapp.configs;

import com.google.gson.Gson;
import com.squareup.moshi.FromJson;
import com.squareup.moshi.ToJson;

import org.json.JSONObject;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.CacheControl;
import okhttp3.ConnectionSpec;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.ResponseBody;
import retrofit2.Converter;
import retrofit2.Retrofit;


public abstract class AbstractRequest {
    protected final OkHttpClient.Builder client;

    public AbstractRequest() {

        // Connection specs
        List<ConnectionSpec> connectionSpecs = new ArrayList<>();
        Collections.addAll(connectionSpecs, ConnectionSpec.MODERN_TLS);

        // Protocols
        List<Protocol> protocols = new ArrayList<>();
        Collections.addAll(protocols, Protocol.HTTP_1_1, Protocol.HTTP_2);

        // http://square.github.io/okhttp/3.x/okhttp/ - Class Cache

        // Create a trust manager that does not validate certificate chains
        final TrustManager[] trustAllCerts = new TrustManager[]{
                new X509TrustManager() {
                    @Override
                    public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType) {
                    }

                    @Override
                    public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                        return new java.security.cert.X509Certificate[]{};
                    }
                }
        };

        // Install the all-trusting trust manager
        SSLContext sslContext = null;

        try {
            sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
        }
        catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (KeyManagementException e) {
            e.printStackTrace();
        }

        client = new OkHttpClient.Builder()
                .connectionSpecs(connectionSpecs)
                .readTimeout(30, TimeUnit.SECONDS)
                .writeTimeout(90, TimeUnit.SECONDS)
                .connectTimeout(15, TimeUnit.SECONDS)
                .retryOnConnectionFailure(getRetryOnConnectionFailure());


        // do not cache the response
        CacheControl noStore = new CacheControl.Builder().noStore().build();
    }

    protected abstract boolean getRetryOnConnectionFailure();


    //https://stackoverflow.com/questions/7910734/gsonbuilder-setdateformat-for-2011-10-26t202959-0700
    public static class DateAdapter {
        DateFormat dateFormat;

        public DateAdapter() {
            try{
                this.dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ssZ");
            }
            catch (IllegalArgumentException exception){
                exception.printStackTrace();
            }
        }


        @ToJson
        String toJson(Date date) {
            return dateFormat.format(date);
        }

        @FromJson
        synchronized Date jsonToDate(String s) throws ParseException {
            return dateFormat.parse(s);
        }
    }

    public static class LinkedHashSetOfStringAdapter {

        @ToJson
        String toJson(LinkedHashMap<String, String[]> data) {
            return new JSONObject(data).toString();
        }

        @FromJson
        synchronized LinkedHashMap<String, String[]> fromJson(String s) throws ParseException {
            return new Gson().fromJson(s, LinkedHashMap.class);
        }
    }

    public static class NullOnEmptyConverterFactory extends Converter.Factory {
        @Override
        public Converter<ResponseBody, ?> responseBodyConverter(Type type, Annotation[] annotations, Retrofit retrofit) {
            final Converter<ResponseBody, ?> delegate = retrofit.nextResponseBodyConverter(this, type, annotations);
            return new Converter<ResponseBody, Object>() {
                @Override
                public Object convert(ResponseBody body) throws IOException {
                    if (body.contentLength() == 0) return null;
                    return delegate.convert(body);
                }
            };
        }
    }
}
