package com.example.attendanceapp

object Definitions {
    const val USER_PIN_WEBSERVICE = "http://v9xkqax3su9jdrhpe-mock.stoplight-proxy.io/"
}