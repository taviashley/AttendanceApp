package com.example.attendanceapp.configs;

import com.example.attendanceapp.service.RequestCallBackService;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;

public class ApiGateway {


    public static RequestCallBackService callMeBackCampaign() {
        Retrofit retrofit = new com.example.attendanceapp.configs.GetRequest.Builder()
                .setTimeout(setConnectionTimeout())
                .build();
        return retrofit.create(RequestCallBackService.class);
    }

    private static OkHttpClient.Builder setConnectionTimeout() {
            return new OkHttpClient.Builder().readTimeout(40000, TimeUnit.MILLISECONDS)
                    .retryOnConnectionFailure(false)
                    .connectTimeout(40000, TimeUnit.MILLISECONDS).writeTimeout(40000, TimeUnit.MILLISECONDS);
    }
}